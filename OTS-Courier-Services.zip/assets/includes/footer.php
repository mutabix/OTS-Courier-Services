<footer>
	<p>© 2016 Geckoboard. All rights reserved.</p>
</footer>

		</div>
	</body>
</html>