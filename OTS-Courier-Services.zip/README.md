#Please Note When Testing:
#The website is currently live on Heroku: https://on-the-spot-courier-services.herokuapp.com/

#However, due to our team using a free database solution heroku does not connect correctly to the database and does not retrieve data from tables all the time - meaning login doesnt always work, and booking data retrieval doesnt work (however, the website does funcion correctly on a local server (localhost)). This was discussed in the tutorial.

#Website Login Details
#Customer: jsmith@gmail.com   ---   Password
Go to login.php --> then click --> employee login
#Driver: bob@gmail.com   ---   Password
#Coordinator: jack@gmail.com   ---   Password

#Burndown Charts, meeting minutes and testing documents are contained within the Supporting Documentation folder
#Task assignments and task progress are within the burndown chart excel document.

#Team 22: Reeve Waugh, Matthew Magin, Samuel Leary, Hayden Muller, Veronica Skartland Kristiansen