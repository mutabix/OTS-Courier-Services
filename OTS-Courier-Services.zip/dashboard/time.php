<?php
    echo time() + mt_rand(50, 999) + mt_rand(1, 99);

?>