<?php
	$customerId = $_SESSION['customerIdLogin'];
?>