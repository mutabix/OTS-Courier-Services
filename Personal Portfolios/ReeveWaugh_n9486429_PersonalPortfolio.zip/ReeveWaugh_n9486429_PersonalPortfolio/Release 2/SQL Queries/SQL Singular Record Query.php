<?php
$customerData = $dbConnection->prepare('SELECT customerID, companyName, firstName, lastName, email, mobileNumber, addressLine1, addressLine2, suburb, state, postcode
FROM customers
WHERE customerID = '.$_GET["id"].'');
$customerData->execute();
?>