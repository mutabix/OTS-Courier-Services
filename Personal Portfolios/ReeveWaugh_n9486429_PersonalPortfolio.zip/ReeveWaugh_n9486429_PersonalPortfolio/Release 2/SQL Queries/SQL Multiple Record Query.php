<?php
$deliveries = $dbConnection->prepare('SELECT deliveryID, shipmentStatus, deliveryDueBy, deliveryAddress, deliveryAddressPostcode, assignedDriver, priority
FROM deliveries
WHERE assignedDriver = "'.$employeeID.'"
ORDER BY deliveryID
LIMIT :limit
OFFSET :offset');
$deliveries->bindParam(':limit', $limit, PDO::PARAM_INT);
$deliveries->bindParam(':offset', $offset, PDO::PARAM_INT);
$deliveries->execute();
?>