<?php
	//Below: Pagination code adapted by Reeve from http://stackoverflow.com/questions/3705318/simple-php-pagination-script
	$total = $dbConnection->query('SELECT
	COUNT(*)
	FROM customers')->fetchColumn();
						
	$limit = 8;
						
	$pages = ceil($total / $limit);
						
	$page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array
	('options' => array
		('default' => 1,
		'min_range' => 1,
		),
	)));
						
	$offset = ($page - 1) * $limit;
						
	$start = $offset + 1;
	$end = min(($offset + $limit), $total);
						
	$prevlink = ($page > 1) ? '<a href="?page=1" title="First page">&laquo;</a> <a href="?page=' . ($page - 1) . '" title="Previous page">&lsaquo;</a>' : '<span class="disabled">&laquo;</span> <span class="disabled">&lsaquo;</span>';
	$nextlink = ($page < $pages) ? '<a href="?page=' . ($page + 1) . '" title="Next page">&rsaquo;</a> <a href="?page=' . $pages . '" title="Last page">&raquo;</a>' : '<span class="disabled">&rsaquo;</span> <span class="disabled">&raquo;</span>';
	echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', $nextlink, ' </p></div>';
	//Above: Pagination code adapted by Reeve from http://stackoverflow.com/questions/3705318/simple-php-pagination-script
						
						
						
	$result = $dbConnection->prepare('SELECT customerID, companyName, firstName, lastName, email, mobileNumber, state
	FROM customers
	ORDER BY companyName
	LIMIT :limit
	OFFSET :offset');
	$result->bindParam(':limit', $limit, PDO::PARAM_INT);
	$result->bindParam(':offset', $offset, PDO::PARAM_INT);
	$result->execute();	
?>